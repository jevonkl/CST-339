package com.gcu.model;

public class MainModel {

}
