package com.gcu.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class RegisterModel {
	@NotNull(message="FirstName Must Be Entered")
	@Size(min=1, max=32, message="FirstName must be between 1-32 characters")
	private String firstname;
	
	@NotNull(message="LastName Must Be Entered")
	@Size(min=1, max=32, message="LastName must be between 1-32 characters")
	private String lastname;
	
	@NotNull(message="User Name Must Be Entered")
	@Size(min=1, max=32, message="User Name must be between 1-32 characters")
	private String username;
	
	@NotNull(message="Password Must Be Entered")
	@Size(min=1, max=32, message="Password must be between 1-32 characters")
	private String password;
	
	@NotNull(message="Enter a valid Birthday with the MM/DD/YYYY Format")
	@Size(min=6, max=20, message="MM/DD/YYYY")
	private String birthday;
	
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	
	@Override
	public String toString() {
		return "RegisterModel [firstname=" +firstname+", lastname=" +lastname+", username=" +username+", password=" +password+ "]";
	}
}
