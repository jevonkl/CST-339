package com.gcu;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.gcu.model.MainModel;

@Controller
@RequestMapping("/main")
public class MainController {
	
	@GetMapping("/")
	public String display(Model model) 
	{
		model.addAttribute("title", "Main Form");
		model.addAttribute("mainModel", new MainModel());
		return "main";
	}
	
	@PostMapping("/domain")
	public String doMain(@Valid MainModel mainModel, BindingResult bindingResult, Model model) 
	{
		if(bindingResult.hasErrors()) 
		{
			model.addAttribute("title", "Main Form");
			return "main";
		}
		
		model.addAttribute("mainModel", mainModel);
		return "MainSuccess";
	}
}